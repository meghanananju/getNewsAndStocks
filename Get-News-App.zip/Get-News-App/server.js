
const express = require("express");
const axios = require("axios");
const cors = require("cors");
const bodyParser = require("body-parser")
const app = express();
const PORT = 3000;

app.use(cors());
app.use(bodyParser.json());
// Fetch news based on country
app.post("/api/news", async (req, res) => {
    const { country, category } = req.body

    if (!country || !category) return res.status(400).json({ error: "Country & category is required" });

    const apiKey = "API_KEY";
    const url = `https://newsapi.org/v2/top-headlines?country=${country}&category=${category}&apiKey=${apiKey}`;

    try {
        const response = await axios.get(url);


        res.json(response.data);
    } catch (error) {
        res.status(500).json({ error: "Error fetching news data" });
    }
});

// Fetch stock market data
app.post("/api/stock", async (req, res) => {
    const { symbol } = req.body;

    if (!symbol) return res.status(400).json({ error: "Stock symbol is required" });

    const apiKey = "API_KEY";
    const url = `https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=${symbol}&apikey=${apiKey}`;

    try {
        const response = await axios.get(url);
        res.json(response.data);
    } catch (error) {
        res.status(500).json({ error: "Error fetching stock data" });
    }
});

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));

