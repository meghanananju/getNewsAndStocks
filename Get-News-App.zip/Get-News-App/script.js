

// Check if input is a stock symbol
function isStockSymbol(input) {
    return /^[A-Za-z]+$/.test(input)
}

// Fetch news from  API
async function fetchNewsData() {
    const countryCategoryInput = document.getElementById("searchInput").value.trim();

    const parts = countryCategoryInput.split(",")
    const inputCountry = parts[0].trim();
    const inputCategory = parts[1].trim();

    try {
        if (!inputCountry || !inputCategory) {
            alert("Please enter country & category");
            return;
        }
        const response = await fetch("http://localhost:3000/api/news", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ country: inputCountry, category: inputCategory })

        });

        if (!response.ok) throw new Error("Failed to fetch news");

        const data = await response.json();

        if (data.articles && data.articles.length > 0) {
            let newsHtml = "";
            data.articles.slice(0, 5).forEach(article => {
                newsHtml += `
                    <div class="news-item">
                        <h4>${article.title}</h4>
                        <p>${article.description || "No description available"}</p>
                        <a href="${article.url}" target="_blank">Read more</a>
                    </div>
                `;
            });
            document.getElementById("newsSection").innerHTML = newsHtml;
        } else {
            document.getElementById("newsSection").innerHTML = "<p>No news found.</p>";
        }
    } catch (error) {
        console.error("Error fetching news:", error);
        document.getElementById("newsSection").innerHTML = "<p>Error loading news.</p>";
    }
}

// Fetch stock data from  API
async function fetchStockData() {
    const stockSymbol = document.getElementById("searchInput").value.trim();

    if (!stockSymbol) {
        alert("Please enter a stock symbol!");
        return;
    }


    try {
        const response = await fetch("http://localhost:3000/api/stock", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ symbol: stockSymbol })
        });

        if (!response.ok) {
            throw new Error(`Error ${response.status}: ${response.statusText}`);
        }

        const data = await response.json();


        if (data && data["Global Quote"]) {
            const stock = data["Global Quote"];
            document.getElementById("stocksSection").innerHTML = `
                <div class="stock-info">
                    <h4>${stockSymbol.toUpperCase()}</h4>
                    <p>Open Price: ${stock["02. open"]}</p>
                    <p>High : ${stock["03. high"]}</p>
                    <p>Low : ${stock["04. low"]}</p>
                    <p>Price: ${stock["05. price"]}</p>
                    <p>Change: ${stock["09. change"]} (${stock["10. change percent"]})</p>
                </div>
            `;
        } else {
            document.getElementById("stocksSection").innerHTML = "<p>Stock data not found.</p>";
        }
    } catch (error) {
        console.error("Error fetching stock data:", error);
        document.getElementById("stocksSection").innerHTML = "<p>Error loading stock data.</p>";
    }
}